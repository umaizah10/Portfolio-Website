# THE IDEA ENGINE — Umaizah Azam

A static, machine-world portfolio built with HTML, CSS and JavaScript only. No backend, database, build step, runtime CDN or server code is required.

## Open and deploy

1. Extract the ZIP.
2. Open `index.html` in a browser, or upload the **contents** of this folder to your Heuser GitHub repository under `CS_CRP/Homework_8/`.
3. In GitHub, open **Settings → Pages** and deploy from the branch/folder that contains these files.
4. Open the published `.../Homework_8/` URL and test the controls.

All internal paths are relative. Fonts, photographs/screenshots, CSS, JavaScript and the favicon are included locally. The site also works from a static host or a locally opened `index.html`; a local preview server is only a convenience, not part of the website.

## Homework 7 — connected

The live Homework 7 URL is:

`https://umaizah10.github.io/Heuser/`

- The Homework 7 output port on every page links directly to this URL.
- It opens in a new tab with `target="_blank"` and `rel="noopener noreferrer"`.
- The same URL is stored in `assets/js/config.js`.
- The HTML carries the direct link too, so the Homework 7 port still works if JavaScript is unavailable.
- `homework7.html` is preserved as a connected bridge page describing the hosted Virtual Pet — Kitty page.

## Pages and physical controls

| Control | Page |
|---|---|
| Main power switch | `index.html` |
| Identity scanner | `about.html` |
| Processing unit | `skills.html` |
| Output chamber | `projects.html` |
| Performance meter | `achievements.html` |
| Blueprint station | `aspirations.html` |
| Communication terminal | `contact.html` |
| Learning archive cartridge | `education.html` |
| Homework 7 output port | Direct live URL, with `homework7.html` preserved as a connected bridge |

There is no traditional header, footer, navbar or sidebar. The repeated control surface is a set of physical-looking machine components with real HTML `href` links.

## Interactions

- One short power-on sequence per browser session on Home, with a skip button.
- Rotating gears, a moving piston, blinking indicators and an identity scan beam.
- A three-stage “Run the idea cycle” control.
- Skill-bank, achievement-channel and blueprint-sheet selectors.
- Native project inspection dialogs with Escape/backdrop closing.
- A contact form that opens a `mailto:` draft; it never claims to send or store a message.
- Copy-email control with a fallback.
- Smooth internal page transitions and a persistent motion toggle.
- Reduced-motion preference is respected by default.

## Current project records

The Output Chamber now shows three projects:

1. **Front-End Library Website** — uses the supplied library screenshot as the main preview.
2. **Techlogix Website** — uses the supplied Techlogix screenshot as the main preview; the short description is based on visible interface elements.
3. **Tic Tac Toe Game** — preserved from the earlier project record, with its public video demo.

The supplied screenshots are stored unchanged in `assets/images/`:

- `frontend-library-website.png`
- `techlogix-website.png`

## Performance meter updates

The Performance Meter keeps the existing evidence-channel design and adds:

- **Pioneer Youth** under volunteering/extracurricular experience, with role **Volunteer**.
- A new **Experience** channel with **SEO Intern**, role **SEO Intern**, presented as a professional work-experience performance card.

No company name, employment dates, responsibilities, outcomes or numeric performance scores were invented for the SEO Intern entry.

## Content sources and honesty

Content was taken from the supplied résumé, the supplied public LinkedIn profile, the supplied photo/screenshots, and the latest user-provided updates.

- Education: Heuser College A Levels — Mathematics, Computer Science, Physics; merit scholarship; CRP; cricket and badminton.
- Volunteering: Dar-ul-Sukun and Pioneer Youth.
- Experience: SEO Intern role only, as supplied.
- Projects: Front-End Library Website, Techlogix Website and Python Tic Tac Toe.
- Achievements: merit scholarship, volunteering, and certificates/learning records listed in the sources.
- Aspirations are explicitly future directions based on stated interests, not invented experience.
- The identity photograph is a crop of the supplied photo. No random person or generated portrait is used.
- The résumé phone number is intentionally omitted from the public site.
- No grades, dates, award ranks, employment claims or skill percentages were invented.

### External-link availability

- Homework 7: connected and verified at `https://umaizah10.github.io/Heuser/`.
- Tic Tac Toe YouTube demo: public and reachable when checked.
- Techlogix demo address from the résumé, `http://technologixsite.liveblog365.com`, returned a DNS/hosting error when checked. It is preserved and clearly labelled, with the LinkedIn project reference provided as an alternative.
- Certificate verification links are the original URLs listed on the public LinkedIn profile. Their availability depends on the issuing services.

## Fonts and assets

Space Grotesk and Manrope are self-hosted Google Fonts under the SIL Open Font License. License files are in `assets/fonts/`. The palette is Graphite `#111315`, Gunmetal `#252B2B`, Copper orange `#D4773F`, Electric lime `#C7E36B`, and Warm ivory `#E9E3D5`.

## Concept text on the website

The Idea Engine turns my portfolio into an interactive machine, with each physical control opening a different part of my story. Instead of a conventional menu, visitors operate switches, scanners and terminals to move between separate pages. It is unconventional because the interface makes exploration feel like bringing a creative system to life.

See `HOMEWORK_8_CHECKLIST.md` for the requirement audit, `TESTING.md` for verification, and `UPDATE_NOTES.md` for the latest targeted changes.
