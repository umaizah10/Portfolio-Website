# Targeted update notes

This update preserves the existing Idea Engine design, palette, typography, layout, animations and interactive machine navigation.

## Changed

1. **Homework 7 link**
   - Connected to `https://umaizah10.github.io/Heuser/`.
   - Opens in a new tab.
   - Updated the control-surface port on every page, `assets/js/config.js`, and the preserved `homework7.html` bridge page.

2. **Performance Meter**
   - Added **Pioneer Youth**, role **Volunteer**, under the service/volunteering channel.
   - Added a new **Experience** channel.
   - Added **SEO Intern**, role **SEO Intern**, as a professional work-experience performance card.
   - Used a recorded-experience indicator rather than inventing a score, company, dates, responsibilities or outcomes.

3. **Output Chamber**
   - Added **Front-End Library Website** using the supplied library screenshot as the main preview.
   - Updated **Techlogix Website** to use the supplied Techlogix screenshot as the main preview.
   - Kept the existing **Tic Tac Toe Game** record and demo link.
   - Updated the Home project count from 02 to 03.

## Preserved

- Machine-world concept and visual identity.
- Existing pages and physical navigation controls.
- Existing animations, motion toggle and reduced-motion behaviour.
- Identity scanner photograph.
- Education, skills, aspirations and contact content.
- Existing project dialogs, demo/profile links and external-link honesty notes.

## Verification

See `TESTING.md`. The updated build passed 104 browser checks with no console errors, no page errors and no missing local assets.
