# Browser and link verification

Date: 12 November 2026

## Automated browser checks

Tested with Chromium via Playwright against a local static server and a `file://` URL.

- 104 browser checks passed.
- Viewports: 1440 × 1000 desktop and 390 × 844 mobile.
- No JavaScript page errors.
- No browser console errors.
- No failed local asset responses.
- All nine HTML pages loaded.
- All physical control links navigated to the correct separate HTML page.
- Current-page markers were correct.
- All visible local images loaded with non-zero natural dimensions.
- Self-hosted Space Grotesk and Manrope loaded.
- No horizontal overflow on any tested page at desktop or mobile width.
- Power-on sequence appeared, auto-completed, and was skipped under reduced motion.
- Gear animation was active when motion was enabled.
- Motion toggle disabled/enabled animations correctly.
- Home idea cycle completed all three stages.
- Skills, achievements and aspirations selectors switched panels correctly.
- Project dialogs opened and closed with Escape and close buttons.
- Copy-email control updated the status message.
- Projects page showed three project cards.
- Front-End Library and Techlogix supplied screenshots loaded as main previews.
- Performance Meter showed four evidence channels.
- Pioneer Youth and the SEO Intern Experience card were present and selectable.
- Homework 7 link opened the correct live URL in a new tab.
- Homework 7 link also worked with JavaScript disabled.
- Projects page loaded from `file://` without a server.

## External links

- Homework 7: `https://umaizah10.github.io/Heuser/` opened successfully and showed the Virtual Pet — Kitty page.
- Tic Tac Toe YouTube demo: public and reachable.
- Certificate/learning-record links: reachable by earlier HTTP check.
- LinkedIn profile: public profile content was verified through page retrieval; LinkedIn may block plain automated HTTP requests.
- Techlogix demo address from the résumé: the host returned a DNS/hosting error page. The site preserves the address and labels it as unavailable, with the LinkedIn project reference as an alternative.

## Pending user action

Upload this folder to the Heuser GitHub repository and enable GitHub Pages. After hosting, confirm the live Homework 7 link from the hosted Homework 8 site before submission.
