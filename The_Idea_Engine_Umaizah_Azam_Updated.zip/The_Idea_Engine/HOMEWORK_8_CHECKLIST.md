# Homework 8 — requirement audit

Checked against both pages of the supplied `Homework_8.pdf`, including the latest requested updates.

| Requirement | Status | Implementation |
|---|---|---|
| Static HTML/CSS/JS only; no backend/server code/database | Pass | Nine static HTML pages, local CSS/JS/assets. The contact form only opens a mailto draft. |
| Works on GitHub Pages; relative paths | Pass | Relative internal links and asset paths; no build step or runtime CDN. |
| At least three unique, unconventional colours | Pass | Graphite, gunmetal, copper orange, electric lime and warm ivory. |
| Meaningful image of yourself | Pass | Supplied photo cropped into the identity scanner and scanner control. |
| No traditional header, footer or navigation bar | Pass | Machine faceplate and physical control surface; no header/footer/nav elements or conventional menu. |
| Unconventional navigation between separate pages | Pass | Eight physical components use real hrefs to separate HTML files. |
| Animations | Pass | Power-on sequence, gears, piston, indicators, scan beam, hover reactions and page transitions. |
| At least one non-default font | Pass | Self-hosted Space Grotesk and Manrope, with OFL licenses. |
| Working href to the hosted Homework 7 website | Pass | Direct link to `https://umaizah10.github.io/Heuser/`, opening in a new tab. |
| Host in Heuser repo, e.g. CS_CRP/Homework_8/ | Pending user action | Deployment instructions are in README.md; repository access was not provided. |
| Bonus: personal-life achievements | Pass | Dar-ul-Sukun volunteering, Pioneer Youth volunteering and sports participation, without invented awards. |
| Bonus: dedicated aspirations section | Pass | `aspirations.html`, based on stated interests and clearly labelled as future directions. |
| No space/planets/stars/galaxies theme | Pass | Industrial machine concept only. |
| Two or three concept sentences on the website | Pass | Three sentences in the Home “Why this machine?” panel. |
| Responsive, connected pages, no missing local assets | Pass | Browser-tested at desktop and mobile widths; local links/assets checked. |
| Preserve real information | Pass | Résumé, public LinkedIn profile, supplied screenshots and latest user updates used; no invented qualifications, awards or experience. |

## Latest requested updates

| Requested update | Status |
|---|---|
| Add actual Homework 7 link and open in new tab | Pass |
| Add Pioneer Youth volunteering to Performance Meter | Pass |
| Add Experience heading and SEO Intern performance card | Pass |
| Add Front-End Library Website using supplied screenshot | Pass |
| Update Techlogix Website using supplied screenshot | Pass |
| Keep existing design, navigation, animations and features | Pass |
| Keep static/GitHub Pages compatible | Pass |

## Known external limitation

The Techlogix demo domain from the résumé returned a DNS/hosting error during the build. The site preserves the address, labels the issue and links to the LinkedIn project reference. This is an external hosting issue, not a missing local file.

## Submission reminders from the PDF

After hosting, submit the live GitHub Pages link and repository link through the course form, and confirm the Homework 7 link works from the site. The form URL printed in the PDF is `https://forms.gle/C7GCquwfFcjYBnHW9`.
